"use client";

import { RouteError } from "@/components/route-error";

export default function StudentRouteError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <RouteError error={error} reset={reset} destination="/student/home" />;
}
